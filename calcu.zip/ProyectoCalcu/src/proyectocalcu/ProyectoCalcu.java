
package proyectocalcu;
import Formulario.newpackage.frmProyectoCalcu;
public class ProyectoCalcu {
    public static void main(String[] args) {
        frmProyectoCalcu frm = new frmProyectoCalcu ();
        frm.setVisible(true);
    }
}
